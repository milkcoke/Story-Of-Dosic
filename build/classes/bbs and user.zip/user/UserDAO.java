package user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO { // DB Access Object  회원 정보를 불러오거나 넣는 클래스
	
	private Connection conn; // DB에 접근하게 해주는 하나의 객체
	private PreparedStatement pstmt;
	private ResultSet rs; // 결과값 정보를 받기 위한 객체
	
	public UserDAO()
	{
		try {
			String dbURL = "jdbc:mysql://localhost:3306/DOSIC?characterEncoding=UTF-8&serverTimezone=UTC"; //3306은 DB서버 Port번호 . DB이름: DOSIC
			String dbID = "root"; //임의로 설정
			String dbPassword = ""; // 임의로 설정
			Class.forName("com.mysql.cj.jdbc.Driver"); // Driver는 mysql에 접속하기 위한 매개체 역할 Library
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public int login(String userID, String userPassword) {
		String SQL = "SELECT userPassword FROM USER WHERE userID= ? ";
		// ID가 실제로 존재하는지, 존재한다면 ID로부터 패스워드를 비교하기 위한 문장. 
		try {
			pstmt = conn.prepareStatement(SQL);
			//정해진 SQL문장을 DB에 삽입하는 object
			pstmt.setString(1,  userID); //  ?에 들어갈 내용
			rs = pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getString(1).equals(userPassword)) // 접속을 시도한 userPassword가 맞다면 (숫자 1은 userPassword칼럼이 1이기 때문에)
					return 1; // 로그인 성공
				else
					return 0; // 비밀번호 틀림.
				}
			return -1; // ID없음.
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -2; // DB오류
	}
	
	public int join(User user) {
		String SQL = "INSERT INTO USER VALUES (?, ? ,?, ?, ?)"; // Insert 문장의 결과 반드시 0이상의 값이 return됨. (음수 리턴시 에러)
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1,  user.getUserNum());
			pstmt.setString(2, user.getUserID());
			pstmt.setString(3, user.getUserPassword());
			pstmt.setString(4, user.getUserName());
			pstmt.setString(5, user.getUserEmail());
			return pstmt.executeUpdate();
		}	catch(Exception e) {
			e.printStackTrace();
		}
		return -1; //데이터 베이스 오류
	}
}